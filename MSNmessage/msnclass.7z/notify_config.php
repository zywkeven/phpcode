<?php

// ADODB include file
$adodb_include = 'adodb/adodb.inc.php';
// database type
$notify_db_type = 'mysql';
// database host
$notify_db_host = 'localhost';
// database user
$notify_db_user = 'dbuser';
// database password
$notify_db_pass = 'dbpassword';
// database name
$notify_db_name = 'dbname';
// table name
$notify_table_name = 'msn_notify';

?>
