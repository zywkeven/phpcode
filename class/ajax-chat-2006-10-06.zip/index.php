<?php
require_once("chat.php");
$chat = new chat();
$chat->main();
?>